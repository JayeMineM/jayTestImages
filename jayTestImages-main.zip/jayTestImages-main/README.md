# jayTestImages
I am JayeMineM, a Data Science PostGrad student with a background in Applied Maths (BSc), Software Manual & Automation Testing (ISTQB CTFL2018 Certificate). 
I have got:
  * Strong analytical and problem solving skills / 
  * Strong communication skills (fluent in English and French) /
  * Attention to details at the verge of being pedantic /
  * Team player/
  * Self-motivated with a great lust of learning.
